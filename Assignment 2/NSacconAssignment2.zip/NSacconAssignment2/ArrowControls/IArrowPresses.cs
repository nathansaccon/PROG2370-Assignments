﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ArrowControls
{
    public interface IArrowPresses
    {
        void UpArrow();
        void DownArrow();
        void LeftArrow();
        void RightArrow();
    }
}
